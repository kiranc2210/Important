# Write a program to get the temperature from the user
# convert it to farenheit

# input

# process

# output