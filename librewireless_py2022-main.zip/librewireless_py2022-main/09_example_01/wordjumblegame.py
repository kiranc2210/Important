# Design a word jumble game
# L P E P S A
# -> [1] ? 
# -> [Hint] This is a fruit
# -> [2] APPLES

import random

# Collection of words
L = ["apples", "laptop", "mangoes", "computer", "mobile", "hyundai", "mercedes", "samsung"]
random.shuffle(L)

# -------------------------------------- Start of task

# Repeat until all words are done
# Pick a word


    # Jumble the word
    

    # Show the word to the user
    

    # Ask for the user input
    

    # Compare the user input with original word
    # Update points
    
# -------------------------------------- End of task

# Print the results
if(points > 6):
    print("Excellent Playing!")
elif(3 <= points <= 6):
    print("Good")
else:
    print("Improvement needed")
