# Program to determine if a number is prime or not

n = int(input("Enter a number: "))


# --------------------------------- Start of task




# --------------------------------- End of task

if(prime == True):
    print("Then number is prime")
else:
    print("The number is not prime")