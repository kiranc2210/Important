# Program to get the number inputs from the user and finding the average of the numbers

# input


# process


# output