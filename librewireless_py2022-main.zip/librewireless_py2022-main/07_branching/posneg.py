# Program to tell if the result was positive, negative or zero
# after subtraction of two numbers

# input
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))


# process
res = a - b

# output
print("-"*50)
print("DIFFERENCE  : ", abs(a - b))

# ---------- print results here with if..else.. block